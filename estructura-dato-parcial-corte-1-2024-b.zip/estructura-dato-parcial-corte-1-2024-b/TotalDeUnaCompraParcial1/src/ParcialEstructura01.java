import javax.swing.*;
import java.util.Scanner;

public class ParcialEstructura01 {
    public static void main(String arg[]) {
        //Variables
        Scanner scanner = new Scanner(System.in);
        Double valor_unitario;
        Double descuento;
        String mensaje = "Error, ingresar dato entre 0.0 y 5.0.";
        String nombre;
        String producto;
        String comprar;

        System.out.print("Digite su nombre: ");
        nombre = scanner.next();

        System.out.print("Digite nombre del producto: ");
        producto = scanner.next();
        if (producto >=0 && producto <=5) {
            System.out.print("Digite la nota del trabajo: ");
            producto = scanner.next();

            System.out.print("Cantidad a comprar: ");
            comprar = scanner.next();
            if (comprar >=0 && comprar <=5){
                System.out.print("Digite la nota del trabajo: ");
                producto = scanner.next();

                    //Si todo se ingreso correctamente, llega hasta aquí.
                     descuento  = (parcial*0.7)+(trabajo*0.15)+(certificacion*0.1)+(autoCoe*0.05);
                    System.out.println(nombre+" su nota definitiva es. "+notaDefinitiva);
                }else{
                    System.out.println(mensaje);
                }
            }else{
                System.out.println(mensaje);
            }
            }
    }
